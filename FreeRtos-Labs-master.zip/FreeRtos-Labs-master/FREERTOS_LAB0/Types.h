#ifndef TYPES_H
#define TYPES_H

typedef unsigned char u8;
typedef unsigned long int uint32;
typedef unsigned long int* puint32;
typedef long int int32;

#endif
