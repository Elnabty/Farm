# FreeRtos-Labs
**FreeRTOS labs of RTOS Course:** http://www.vlsiacademy.org/rtos1.html

Feel free to use these codes in anyway.
