Die Hexfiles sind nur f�r das ETH_M32_EX Board mit einem 16MHz Quarz von meiner Homepage www.ulrichradig.de
