#pragma once

#define VC_EXTRALEAN
#include <afxwin.h>
#include <afxsock.h>
#include <afxcmn.h>
