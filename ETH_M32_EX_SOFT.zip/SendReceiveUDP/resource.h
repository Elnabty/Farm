//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SendReceive.rc
//
#define IDR_MAINFRAME                   1
#define IDP_SOCKETS_INIT_FAILED         2
#define IDD_FORMVIEW                    101
#define IDD_OPEN_DIALOG                 102
#define IDC_MESSAGE                     1000
#define IDC_IPADDRESS1                  1001
#define IDC_PORT                        1002
#define IDC_DATA                        1006
#define IDC_DATA_RECEIVED               1007
#define IDC_CLEAR_BUTTON                1016
#define IDC_IPADDRESS                   1017
#define IDC_TIME                        1018
#define IDC_FROM                        1019
#define IDC_DATA_RECEIVED_HEADER        1020
#define ID_ADDRESS                      40001
#define IDM_LOOPBACK                    40002
#define IDM_BROADCAST                   40003
#define IDM_SEND                        40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
