
#ifndef __adc_h__
#define __adc_h__

extern uint16_t analog_read(uint8_t);
extern void 	adc_init(void);

#endif