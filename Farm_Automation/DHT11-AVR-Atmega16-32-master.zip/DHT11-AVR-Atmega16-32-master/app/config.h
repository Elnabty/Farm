
#ifndef __config_h__
#define __config_h__

#define F_CPU 8000000UL

#endif